import { appHome, exec, readTextFile } from "herdr";

export const jobId = () => Array.from({length:32}, () => Math.floor(Math.random()*16).toString(16)).join("");

export async function bridge(request) {
  const home = appHome();
  const feature = ["revision","preview","render","image","text","html-preview","html-open"].includes(request.action) ? "pdf" : "transfer";
  try {
    const config = JSON.parse(await readTextFile(`${home}/data/herdr-mod-kit/helpers/runtime.json`));
    const result = await exec(config.python, ["-X", "utf8", `${home}/data/herdr-mod-kit/helpers/bridge.py`, "--hc", config.hc, "--home", home, "--request", JSON.stringify(request)], { timeout: 600000 });
    if (result.code !== 0) throw new Error("Helper stopped");
    return JSON.parse(result.stdout);
  } catch {
    console.error(`[herdr-kit/${feature}] helper_unavailable action=${request.action}`);
    throw new Error("File helper unavailable. Run the kit diagnostics and retry.");
  }
}

export function uploadRequests(paths, directory, on) {
  return paths.map(source => ({action:"upload",source,directory,on,job:jobId()}));
}
